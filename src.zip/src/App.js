
import './App.css';
import RegisterForm from './components/form';

function App() {
  return (
      <RegisterForm />
  
  );
}

export default App;

